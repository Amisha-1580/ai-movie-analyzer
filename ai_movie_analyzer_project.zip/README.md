# AI Movie Analyzer

A beginner‑friendly web app that lets you search the IMDb Top‑1000 dataset, backed by MongoDB Atlas and Flask.

## Features
- **Search** by movie title (regex search).
- **Results** show genre, overview, rating.
- Easy to extend with MongoDB Atlas *Vector Search* or Vertex AI summaries.

## Stack
| Layer | Tech |
|-------|------|
| Backend | Python 3 + Flask |
| Database | MongoDB Atlas (free tier) |
| Front‑end | HTML/CSS/JS (vanilla) |
| Hosting (optional) | Google Cloud Run or Render |

## Quick Start

```bash
git clone <repo>
cd ai-movie-analyzer-project
python -m venv venv
venv\Scripts\activate   # macOS/Linux: source venv/bin/activate
pip install -r requirements.txt

# set your MongoDB URI
set MONGO_URI="mongodb+srv://<user>:<pwd>@cluster0.xxx.mongodb.net/?retryWrites=true&w=majority"

python app.py
```

Then open <http://127.0.0.1:5000> in your browser.

## Dataset

Import `imdb_top_1000.csv` into a collection named `movies` in a database named `movies_db` (see tutorial).  
You can download it from Kaggle: https://www.kaggle.com/datasets/harshitshankhdhar/imdb-dataset-of-top-1000-movies-and-tv-shows

---

Feel free to extend this repo for the MongoDB Atlas Hackathon!
